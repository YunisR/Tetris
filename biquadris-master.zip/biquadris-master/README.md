# Biquadris

Final Project for CS 246, by Yunis Ruken, David Lu, Joey Zhong.
