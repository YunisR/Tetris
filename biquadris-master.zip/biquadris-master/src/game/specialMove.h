#ifndef SPECIAL_MOVE_H
#define SPECIAL_MOVE_H

enum class SpecialMove {NoMove, Blind, Heavy, Force};

#endif
